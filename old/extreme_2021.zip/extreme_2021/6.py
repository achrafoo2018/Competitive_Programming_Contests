import numpy as np
n = int(input())
for _ in range(n):
    arr = [int(i) for i in input().split(" ")] 
    print(np.)