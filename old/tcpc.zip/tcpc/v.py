with open("cipher.in", 'r') as file:
    et = file.readline()
    dt = file.readline()
    s = ""
    for i in range(len(et)):
        s += str(int(et[i]) - int(dt[i]) + 97)
    print(s)