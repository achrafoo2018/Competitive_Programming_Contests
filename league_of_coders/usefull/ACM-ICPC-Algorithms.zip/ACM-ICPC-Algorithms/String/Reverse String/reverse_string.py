def reverse(string):
  return string[::-1]
  
if __name__ == '__main__':
  print(reverse("reverse")) # Output "esrever"
  print(reverse("Three can keep a secret, if two of them are dead")) # Output "daed era meht fo owt fi ,terces a peek nac eerhT"
  print(reverse("ACM-ICPC-Algorithms")) # Output "smhtiroglA-CPCI-MCA"
