<h1>Insertion Sort</h1>
<p>Insertion sort is a simple sorting algorithm that builds the final sorted array (or list) one item at a time. It is much less efficient on large lists than more advanced algorithms such as quicksort, heapsort, or merge sort.</p>

<img src="https://upload.wikimedia.org/wikipedia/commons/4/42/Insertion_sort.gif">

<a href="https://en.wikipedia.org/wiki/Insertion_sort">Source: Wikipedia</a>