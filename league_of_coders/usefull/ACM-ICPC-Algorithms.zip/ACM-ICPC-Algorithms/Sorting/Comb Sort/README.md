<h1>Comb Sort</h1>
<p>Comb sort is a relatively simple sorting algorithm originally designed by Włodzimierz Dobosiewicz in 1980. Later it was rediscovered by Stephen Lacey and Richard Box in 1991. Comb sort improves on bubble sort.</p>
<img src="https://upload.wikimedia.org/wikipedia/commons/4/46/Comb_sort_demo.gif">

<a href="https://en.wikipedia.org/wiki/Comb_sort">Source: Wikipedia</a>