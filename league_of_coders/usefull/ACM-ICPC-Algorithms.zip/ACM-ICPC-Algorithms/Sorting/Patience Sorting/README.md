<h1>Patience Sorting</h1>
<p>In computer science, patience sorting is a sorting algorithm inspired by, and named after, the card game patience. A variant of the algorithm efficiently computes the length of a longest increasing subsequence in a given array.</p>

<a href="https://en.wikipedia.org/wiki/Patience_sorting">Source: Wikipedia</a>