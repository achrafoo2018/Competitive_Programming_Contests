## Description of the problem

There is a merchant ship whose capacity to load is K tons and a set of containers with their respective weights
Design an algorithm to:
-Maximize the number of containers: We will introduce the containers in a
growing in weight.
-Maximize the loaded weight: We will introduce the containers in a
growing in weight.
